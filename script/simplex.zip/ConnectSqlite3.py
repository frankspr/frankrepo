#coding:utf-8
#v1.0
import sqlite3
cx = sqlite3.connect("C:/hjhuang/CMDB/config.db")
cu = cx.cursor()
cu.execute("select * from passinfo")
i = 0
for item in cu.fetchall():
    for element in item:
        print element
        print i
        
        
