import os
import pycurl

fp = open('C:\Users\Frank\Desktop\serlst.txt','r')
for line in fp.readlines():
    print line 

