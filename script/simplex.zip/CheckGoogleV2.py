#coding:utf-8
import httplib
import time
import ctypes
import struct
import json
import socket
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header

STD_INPUT_HANDLE = -10  
STD_OUTPUT_HANDLE= -11  
STD_ERROR_HANDLE = -12  
  
FOREGROUND_BLACK = 0x0  
FOREGROUND_BLUE = 0x01 # text color contains blue.  
FOREGROUND_GREEN= 0x02 # text color contains green.  
FOREGROUND_RED = 0x04 # text color contains red.  
FOREGROUND_INTENSITY = 0x08 # text color is intensified.  
  
BACKGROUND_BLUE = 0x10 # background color contains blue.  
BACKGROUND_GREEN= 0x20 # background color contains green.  
BACKGROUND_RED = 0x40 # background color contains red.  
BACKGROUND_INTENSITY = 0x80 # background color is intensified.  
#定义字体颜色  
class Color:  
    ''''' See http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winprog/winprog/windows_api_reference.asp 
    for information on Windows APIs.'''  
    std_out_handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)  
      
    def set_cmd_color(self, color, handle=std_out_handle):  
        """(color) -> bit 
        Example: set_cmd_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY) 
        """  
        bool = ctypes.windll.kernel32.SetConsoleTextAttribute(handle, color)  
        return bool  
      
    def reset_color(self):  
        self.set_cmd_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE)  
      
    def print_red_text(self, print_text):  
        self.set_cmd_color(FOREGROUND_RED | FOREGROUND_INTENSITY)  
        print print_text  
        self.reset_color()  
          
    def print_green_text(self, print_text):  
        self.set_cmd_color(FOREGROUND_GREEN | FOREGROUND_INTENSITY)  
        print print_text  
        self.reset_color()  
      
    def print_blue_text(self, print_text):   
        self.set_cmd_color(FOREGROUND_BLUE | FOREGROUND_INTENSITY)  
        print print_text  
        self.reset_color()  
            
    def print_red_text_with_blue_bg(self, print_text):  
        self.set_cmd_color(FOREGROUND_RED | FOREGROUND_INTENSITY| BACKGROUND_BLUE | BACKGROUND_INTENSITY)  
        print print_text  
        self.reset_color() 

#define zabbix sender
class zabbix_sender:
        def __init__(self,zbx_server_host,zbx_server_port):
                self.zbx_server_host=zbx_server_host
                self.zbx_server_port=zbx_server_port
                self.zbx_header='ZBXD'
                self.zbx_protocols_version=1
                self.zbx_send_value={'request':'sender data','data':[]}
        def adddata(self,host,key,value):
                add_data={'host':host,'key':key,'value':value}
                self.zbx_send_value['data'].append(add_data)
        #封装数据包
        def makesenddata(self):
                zbx_send_json=json.dumps(self.zbx_send_value)
                zbx_send_json_len=len(zbx_send_json)
                self.zbx_send_data=struct.pack("<4sBq"+str(zbx_send_json_len)+"s",'ZBXD',1,zbx_send_json_len,zbx_send_json)
        def send(self):
                self.makesenddata()
                zbx_server_socket=socket.socket()
                zbx_server_socket.connect((self.zbx_server_host,self.zbx_server_port))
                zbx_server_write_df=zbx_server_socket.makefile('wb')
                zbx_server_write_df.write(self.zbx_send_data)
                zbx_server_write_df.close()
                zbx_server_read_df=zbx_server_socket.makefile('rb')
                zbx_response_package=zbx_server_read_df.read()
                zbx_server_read_df.close()
                #解数据包
                zbx_response_data=struct.unpack("<4sBq"+str(len(zbx_response_package) - struct.calcsize("<4sBq"))+"s",zbx_response_package)
                return zbx_response_data[3]

#define sendmail
def SendMail(html):
        From = 'auto-push@pyyx.com'
        To = ['huanghuajin@pyyx.com']
#        subject = 'python email test'
        smtpserver = 'smtp.exmail.qq.com'
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "%s %s" % ( '',Header("VPN检查","utf-8"))
        msg['From']= From
        msg['To']=",".join(To)
        username = 'auto-push@pyyx.com'
        password = 'Yinxiang001'
        part = MIMEText(html,'html')
        msg.attach(part)
        print "Send mail......"
        smtp = smtplib.SMTP()
        smtp.connect('smtp.exmail.qq.com')
        smtp.login(username,password)
        smtp.sendmail(From, To, msg.as_string())
        smtp.quit()

		
clr = Color()
zabbix_sender=zabbix_sender('192.168.1.3',10051)
while True:

  googleaddr = ['www.google.co.jp','www.google.com.hk']
  lst = []

  f = open('check.log','a')
  for ip in googleaddr:
    conn = httplib.HTTPSConnection(ip,timeout=20)
    try:
      print "Start to check %s..." % ip
      conn.request('GET', '/', headers = { 
                                            "User-Agent" : "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.1) Gecko/20090624 Firefox/3.5", 
                                            "Accept" : "*/*", 
                                            "Accept-Encoding" : "gzip,deflate", 
    }) 
      res = conn.getresponse()
      Ctime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
      clr.print_green_text(Ctime+' '+ip+' '+str(res.status))
      
      lst.append(res.status)
     
      f.write(Ctime+' '+ip+' '+str(res.status)+'\n')

    except Exception,e:
#      clr.pring_red_text(ip)
      clr.print_red_text(e)
    finally:
      conn.close()
  f.close()

  if len(lst) > 0:
    
    clr.print_green_text('Success!')
    #zabbix_sender=zabbix_sender('192.168.1.3',10051)
 #   zabbix_sender.adddata('dev001','pyyx.googlecheck','1')
 #   response=zabbix_sender.send()
    #print response
    #html = """google access success!"""
   # SendMail(html)
  else:
  #  zabbix_sender.adddata('dev001','pyyx.googlecheck','0')
  #  response=zabbix_sender.send()
    #print response
    print clr.print_red_text("Connecting timeout!")
    html = """google access timeout"""
    SendMail(html)
  time.sleep(300)
  
    
