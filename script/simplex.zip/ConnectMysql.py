#!/usr/bin/pyton6
#coding: utf-8  
import string
import MySQLdb
import smtplib  
from email.mime.multipart import MIMEMultipart  
from email.mime.text import MIMEText  
from email.mime.image import MIMEImage
import sqlite3
import os
      
From = 'op.alert@wind.com.cn'  
To = 'hjhuang@wind.com.cn'  
subject = 'python email test'  
smtpserver = 'shms3.wind.com.cn:250'  
#username = '***'  
#password = '***'  
      
# Create message container - the correct MIME type is multipart/alternative.  
msg = MIMEMultipart('alternative')  
msg['Subject'] = "IM 聊天数据及头像数据备份检查"
msg['From']= From
msg['To']=To  
#dbname='mydb' 
list_result=[]
# Create the body of the message (a plain-text and an HTML version). 
def fun_mysqlimport():
    with open("file2.txt", "rt") as handle:
        datas = [ln.split('\t') for ln in handle]
        print datas
        conn = MySQLdb.connect(host='127.0.0.1', user='wind', passwd='123456', db='test')
        curr = conn.cursor()
        curr.executemany("insert into www values (%s, %s);", datas)
        conn.commit()
        conn.close()
fun_mysqlimport
def fun_mysql(list):
    conn = MySQLdb.connect(
        host = '10.20.172.60',
        port = 3306,
        user = 'eagle',
        passwd = 'monitor',
        db = 'test'
        )
    cur = conn.cursor()
    cur.execute("select dirpartinfo.ID,dirpart,round((FILESIZE)/1024,2),LOGTIME FROM dirpartinfo JOIN IMFILEINFO ON dirpartinfo.ID=IMFILEINFO.ID;")
#print type(cur.fetchall())
    print "Rows selected:",cur.rowcount
    print "******"
    print list
    print "******"
    for row in cur.fetchall():
        print "%s %s %s %s" %(row[0],row[1],row[2],row[3])
        print type(list)
        print type(row[0])
        list.append(row[0])
        list.append(row[1])
        list.append(row[2])
        list.append(row[3])
    print "******"
    print list
    print "******"
    cur.close()
    conn.commit()
    conn.close()
    return list
#BODY = '''
#        From:{0}
#        TO:{1} 
#        Subject:{2}
#        {3}
#        '''.format(From,To,Subject,text)

html_1 = """ 
<html> 
<head></head> 
<style>
h2 { border-bottom: 2px sold #D8D8D8 }"
table { text-align:left; border:1px 0px 0px 0px;}
table td { height:20px; background-color: white; border-bottom:1px solid #D8D8D8; border-right:1px solid #D8D8D8; border-left:0px; border-top:0px; padding-right:5px;}
table th { height:20px;text-align:center; border-bottom:1px solid #D8D8D8;border-right:1px solid #D8D8D8;border-left:0px;border-top:0px;padding-right:5px;padding-left:5px;}
table td.sync, table td.info { color: black;}
table td.alert, table td.checking  { color: #ff9900; }
table td.fatal, table td.error, table td.out_sync { color: red;}
body { font-family: Arial; font-size: 12px; color:#4a5cc2;  width:95%; }
</style>
</html>
<html>
<head></head>
<body>
<h2>IM数据备份汇总</h2>
<table border="1">
<tr>
<td>ID</td>
<td>备份目录</td>
<td>目录大小(M)</td>
<td>检查时间</td>
</tr>
"""
#html_2 = """
#<tr>
#<td>{0}</td>
#<td>{1}</td>
#<td>{2}</td>
#</tr>
#"""
#html_3 = """
#<tr>
#<td>{0}</td>
#<td>{1}</td>
#<td>{2}</td>
#</tr>
#</table>
#</body>
#</html>
#"""
def sendmail(html):
# Record the MIME types of both parts - text/plain and text/html.  
#part1 = MIMEText(text, 'plain')  
    part2 = MIMEText(html, 'html')  

# Attach parts into message container.  
# According to RFC 2046, the last part of a multipart message, in this case  
# the HTML message, is best and preferred.  
#msg.attach(part1)  
    msg.attach(part2)  
#构造附件  
#att = MIMEText(open('h:\\python\\1.jpg', 'rb').read(), 'base64', 'utf-8')  
#att["Content-Type"] = 'application/octet-stream'  
#att["Content-Disposition"] = 'attachment; filename="1.jpg"'  
#msg.attach(att)  

    print "IM聊天数据检查"
#fun_mysql
    smtp = smtplib.SMTP()  
    smtp.connect('shms3.wind.com.cn:250')  
#smtp.login(username, password)  
    smtp.sendmail(From, To, msg.as_string())  
    smtp.quit()


if __name__=='__main__':
    list_result = fun_mysql(list_result)
    print list_result
    html_2 = """
        <tr>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        </tr>
        """ % (list_result[0],list_result[1],list_result[2],list_result[3])
    html_3 = """
    <tr>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    </tr>
    </table>
       </body>
       </html>
    """ % (list_result[4],list_result[5],list_result[6],list_result[7])
#    html_4 = """
#        <tr>
#        <td>%s</td>
#        <td>%s</td>
#        <td>%s</td>
#        </tr>
#    </table>
#    </body>
#    </html>
#        """ % (list_result[6],list_result[7],list_result[8])

    print "**********"
    print html_2
    print "**********"
    print html_3
    print "**********"
    html = html_1+html_2+html_3
    print "mail send success"
    sendmail(html)
