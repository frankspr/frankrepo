#coding:utf-8
import os
import MySQLdb
import time

Yesterday = time.strftime('%Y%m%d',time.localtime(time.time()-24*60*60))

def genstatus():
  fp = file('/data/nginxlog/statussum-0918.txt','rb')
  val = []
  for line in fp.readlines():
    lst = line.strip().split(' ')
    lst.append(Yesterday)
    val.append(lst)
	return val

	
def genipinfo():
  fp = file('/data/nginxlog/IPtop100.txt','rb')
  ipinfo = []
  for line in fp.readlines():
    lst = line.strip().split(' ')
    lst.append(Yesterday)
    ipinfo.append(lst)
	return ipinfo

def InsertMysql():
  try:
    conn = MySQLdb.connect(
           host = '192.168.1.58',
           port = 3306,
           user = 'pyyx',
           passwd = 'yueren123',
           db = 'nginxlog'
    )
  except MySQL.Error,e:
    print "MySQL Error:%s" % str(e)
  cur = conn.cursor()
  query1="insert into statusinfo (ID,COUNTSUM,STATUSCODE,DATETIME)values(NULL,%s,%s,%s)"
  cur.executemany(query1,val)
  query2="insert into statusinfo (ID,ACCESSCOUNT,ACCESSIP,DATETIME)values(NULL,%s,%s,%s)"
  cur.executemany(query2,ipinfo)
  cur.close()
  conn.commit()
  conn.close()

if __name__ == '__main__':
  genstatus()
  genipinfo()
  InsertMysql()

