#coding:gbk
#Version 1.0
#!/usr/bin/python 
import paramiko
import time
import sys
import getopt
"""
def usage():
    print 
ʹ��˵����
--------------------------------------------
||V1.0 2016-04-29  ������Ȩ�û�            ||
--------------------------------------------
||.\CreateUserV1.py username               ||
--------------------------------------------

    sys.exit()

opts,args = getopt.getopt(sys.argv[1:],"hn:",["help","name="])
input_file=""
output_file=""
for op,value in opts:
    if op in ("-h","--help"):
        input_file = value
        usage()
        sys.exit()
        print input_file
    if op in ("-n"):
        output_file = value
        print output_file
        print type(output_file)
        cusername = output_file
        #return cusername
        #main()
    if op == "":
        usage()
        sys.exit()

"""
        



server_ip = '121.43.175.208'

#server_ip = '192.168.1.6'
server_user = 'root'
server_passwd = 'jhj-ere212edDDVBmmlspring'
#server_passwd = 'wind2010'
server_port = 22
 
def ssh_connect(command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(server_ip, server_port,server_user,server_passwd)
        stdin, stdout,stderr =ssh.exec_command(command)
        err = stderr.readline()
        
        
        for item in stderr.readline():
            print item.strip('\n')
            #print type(item)
    except Exception as e:
        print e
    
     
def ssh_disconnect(client):
    client.close()
     
def win_to_linux(localpath, remotepath):
    '''
    windows��linux�������ϴ��ļ�.
    localpath  Ϊ�����ļ��ľ���·�����磺D:  tttt.py
    remotepath Ϊ�������˴���ϴ��ļ��ľ���·��,������һ��Ŀ¼���磺/tmp/my_file.txt
    '''
    client = paramiko.Transport((server_ip, server_port))
    client.connect(username = server_user, password = server_passwd)
    sftp = paramiko.SFTPClient.from_transport(client)
 
    sftp.put(localpath,remotepath)
    client.close()
     
def linux_to_win(localpath, remotepath):
    '''
    ��linux�����������ļ�������
    localpath  Ϊ�����ļ��ľ���·�����磺D:  tttt.py
    remotepath Ϊ�������˴���ϴ��ļ��ľ���·��,������һ��Ŀ¼���磺/tmp/my_file.txt
    '''
    client = paramiko.Transport((server_ip, server_port))
    client.connect(username = server_user, password = server_passwd)
    sftp = paramiko.SFTPClient.from_transport(client)
 
    sftp.get(remotepath, localpath)
    client.close()



def main():
    if len(sys.argv[1]) != 0:
        cusername = sys.argv[1]
        execommand = "sh  /root/scrips/CreateUser.sh %s" % cusername 
        win_to_linux('C:\hjhuang\Script\pubkey\id_rsa.pub','/root/scrips/id_rsa.pub')
        ssh_connect(execommand)
    else:
        print "Error"
if __name__ =='__main__':
    main()



