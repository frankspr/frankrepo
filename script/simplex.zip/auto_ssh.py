#!/usr/bin/env python
import os
def user_add():
	groupadd = "groupadd %s" % user_name
	useradd = "useradd %s -g %s -s /bin/bash" % (user_name,user_name)
	remote_addgroup = "ansible %s -i /etc/ansible/hostlist -m shell -a 'groupadd %s'" % (host,user_name)
	remote_adduser = "ansible %s -i /etc/ansible/hostlist -m shell -a 'useradd %s -g %s -s /bin/bash'" % (host,user_name,user_name)
	os.system(groupadd)
	os.system(useradd)
	os.system(remote_addgroup)
	os.system(remote_adduser)
def generate_ssh():
	su_user = "su %s" % user_name
	ge_ssh = "sudo -u %s ssh-keygen -t rsa" % user_name
	mk_file = "ansible %s -i /etc/ansible/hostlist -m shell -a 'touch /home/%s/.ssh/authorized_keys'" % (user_name,user_name)
	copy_pub = "ansible %s -i /etc/ansible/hostlist -m copy -a 'src=/home/%s/.ssh/id_rsa.pub dest=/home/%s/.ssh/'" % (host,user_name,user_name)
	transfer = "ansible %s -i /etc/ansible/hostlist -m shell -a 'cat /home/%s/.ssh/id_rsa.pub >> /home/%s/.ssh/authorized_keys mode=0600'" % (host,user_name,user_name)
	os.system(ge_ssh)
	os.system(mk_file)
	os.system(copy_pub)
	os.system(transfer)
if __name__ == "__main__":
	user_name = raw_input("Please input username:")
	f = open("/etc/ansible/hostlist")
	line = f.readline()
	while line:
        	addr = line.strip().split('.')
        	if len(addr) == 4:
        	   	host = line.strip()
        	line = f.readline()
	f.close()
	user_add()
	generate_ssh()

