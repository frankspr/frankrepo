#!/usr/bin/python
#coding:utf-8
#get hostgroups info
import json
import urllib2
url = "http://zabbix.pyyx.com/api_jsonrpc.php"
header = {"Content-Type":"application/json"}

def get_hostgroups():
  data = json.dumps(
  {
  	"jsonrpc":"2.0",
  	"method":"hostgroup.get",
  	"params":{
  	"output":["groupid","name"],
  	},
  	"auth":"5792fe23e498f1ecfc24d0773fd2071e",
  	"id":1,
  })
  request = urllib2.Request(url,data)
  for key in header:
    request.add_header(key,header[key])
  try:
    result = urllib2.urlopen(request)
  except URLError as e:
    if hasattr(e,'reason'):
      print 'Failed to reach server.'
      print 'Reason:',e.reason
    elif hasattr(e,'code'):
      print 'The server can not fulfill the request.'
      print 'Error code:',e.code
  else:
    response = json.loads(result.read())
    print response
    result.close()
    print "Number of hosts:",len(response['result'])
    for group in response['result']:
      print "Group ID:",group['groupid'],"\tGroupName:",group['name']


