#coding:utf-8
while True:
  print "xxxxx"