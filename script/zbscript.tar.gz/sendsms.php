#!/opt/php5.6/bin/php
<?php
include_once('/opt/zabbix-server/share/zabbix/alertscripts/InstantSendMSG.php');

InstantSendMSG::sendsmsmultiphones(array($argv[1]), $argv[2], true);
//InstantSendMSG::sendsmsmultiphones(array($argv[1]), $argv[2], true);

$MSG = $argv[1];
//$PhoneLst = array('18501751292',
//                  '18501751292'
//                    );
//InstantSendMSG::sendsmsmultiphones(array('18501751292'),$MSG true);
	echo $MSG;
?>
