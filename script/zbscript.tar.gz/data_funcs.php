<?php



function hourlyRegisteredNum($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(FROM_UNIXTIME(created_at),13) date_hour, COUNT(*) num FROM `user`
            WHERE created_at >=".$minDateTime." AND created_at <= ".$maxDateTime." AND state = 2
            GROUP BY LEFT(FROM_UNIXTIME(created_at),13) ORDER BY created_at ASC";

    //echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}

function dailyRegisteredNum($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(FROM_UNIXTIME(created_at),10) date_day, COUNT(*) num FROM `user`
            WHERE created_at >=".$minDateTime." AND created_at <= ".$maxDateTime." AND state = 2
            GROUP BY LEFT(FROM_UNIXTIME(created_at),10) ORDER BY created_at ASC";

    //echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_day']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}


function dailyActivedNum($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(FROM_UNIXTIME(end_at),10) date_day, COUNT(*) num FROM `user_activity`
            WHERE end_at >=".$minDateTime." AND end_at <= ".$maxDateTime." 
            GROUP BY LEFT(FROM_UNIXTIME(end_at),10) ORDER BY end_at ASC";

    //echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_day']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}


function hourlyRegisteredNumNew($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(created_at,13) date_hour, COUNT(*) num FROM `t_admin_user`
            WHERE unix_timestamp(created_at) >=".$minDateTime." AND unix_timestamp(created_at) <= ".$maxDateTime." 
            GROUP BY LEFT(created_at,13) ORDER BY created_at ASC";

 //   echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}

function minutelyRegisteredNumNew($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(created_at,16) date_hour, COUNT(*) num FROM `t_admin_user`
            WHERE unix_timestamp(created_at) >=".$minDateTime." AND unix_timestamp(created_at) <= ".$maxDateTime." 
            GROUP BY LEFT(created_at,16) ORDER BY created_at ASC";

 //   echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}

function recentDayMinutelyRegisteredNumNew($link = NULL)
{
    $strQuery = "SELECT LEFT(created_at,16) date_hour, COUNT(*) num FROM `t_admin_user`
            WHERE unix_timestamp(created_at) >= unix_timestamp()-3600*24 
            GROUP BY LEFT(created_at,16) ORDER BY created_at ASC";

 //   echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}




function hourlyImpNumNew($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(created_at,13) date_hour, COUNT(*) num FROM `t_imp_stat`
            WHERE unix_timestamp(created_at) >=".$minDateTime." AND unix_timestamp(created_at) <= ".$maxDateTime." 
            GROUP BY LEFT(created_at,13) ORDER BY created_at ASC";

    echo "$strQuery";
    
    $result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}


function hourlyImpNum($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(FROM_UNIXTIME(created_at),13) date_hour, COUNT(*) num FROM `impression`
            WHERE created_at >=".$minDateTime." AND created_at <= ".$maxDateTime." 
            GROUP BY LEFT(FROM_UNIXTIME(created_at),13) ORDER BY created_at ASC";

    //echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}


function recentDayMinutelyImpNum($link = NULL)
{
    $strQuery = "SELECT LEFT(created_at,16) date_hour, COUNT(*) num FROM `t_imp_stat`
            WHERE unix_timestamp(created_at) >=unix_timestamp()-3600*24 GROUP BY LEFT(created_at,16) ORDER BY created_at ASC";

    echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}


function minutelyImpNum($minDate, $maxDate, $link = NULL)
{
    $minDateTime = strtotime($minDate);
    $maxDateTime = strtotime($maxDate . '23:59:59');
    $strQuery = "SELECT LEFT(created_at,16) date_hour, COUNT(*) num FROM `t_imp_stat`
            WHERE unix_timestamp(created_at) >=".$minDateTime." AND unix_timestamp(created_at) <= ".$maxDateTime." 
            GROUP BY LEFT(created_at,16) ORDER BY created_at ASC";

    echo "$strQuery";
	$result = mysqli_query($link, $strQuery);
    if(!$result)
    {
        echo mysqli_error($link);
    }
    $data = array();
	while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))
    {
        $data[$row['date_hour']] = $row['num'];
	}
        echo mysqli_error($link);
    return $data;
}



?>
