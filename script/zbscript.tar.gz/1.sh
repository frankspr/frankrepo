#!/bin/bash
###SCRIPT_NAME:weixin.sh###
###send message from weixin for zabbix monitor###
###cuiss###
###V1-2016-01-01###

CropID='wx2e23fa87ea766f76'
Secret='1pVl8U8k-6L7xiMbhVxkKljoi0FRlppzEMvmWhogvtFRM7mXJe9Q7ejTqGT5alId'
GURL="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$CropID&corpsecret=$Secret" 
#GURL="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=wx2e23fa87ea766f76&corpsecret=wind2010" 
Gtoken=$(/usr/bin/curl  $GURL -H "DNT: 1" -H "Accept-Encoding: gzip, deflate" -H "Accept-Language: zh-CN,zh;q=0.8" -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 BIDUBrowser/8.1 Safari/537.36" -H "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8" -H "X-DevTools-Emulate-Network-Conditions-Client-Id: B546FC80-414C-403F-95F0-EB0F70E58EF7" -H "Connection: keep-alive" -H "Cache-Control: max-age=0" --compressed | awk -F \" '{print $4}')

PURL="https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=$Gtoken"
function body() {
        local int appId=1                        
        local userId=$1                         
        local partyId=1                    
        local msg=$(echo "$@" | cut -d" " -f3-) 
	printf '{\n'
        printf '\t"touser":"'"$userId"\"",\n"
        printf '\t"toparty":"'"$partyId"\"",\n"
        printf '\t"msgtype": "text",'"\n"
        printf '\t"agentid":"'"$appId"\"",\n"
        printf '\t"text":{\n'
        printf '\t\t"content":"'"$msg"\"
        printf '\n\t},\n'
        printf '\t"safe":"0"\n'
        printf '}\n'
}
body $1 $2 $3
/usr/bin/curl --data-ascii "$(body $1 $2 $3)" $PURL
