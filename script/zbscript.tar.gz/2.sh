curl https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=RZSuTHIdOQTDFQktnIL3RSqtRU_V6a6Zm8YurFBRyR6J00uNQljGzgSChrbAwLKO -d  "{ \
   \"touser\": \"frank\", \
   \"msgtype\": \"text\", \
   \"agentid\": 1, \
   \"text\": { \
       \"content\": \"Hello,I’m itnihao\" \
   }, \
   \"safe\":\"0\" \
}"
