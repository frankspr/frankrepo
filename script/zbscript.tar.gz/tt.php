#!/opt/php5.6/bin/php
<?php
include_once('./InstantSendMSG.php');

InstantSendMSG::sendsmsmultiphones(array($argv[1]), $argv[2], true);

?>
