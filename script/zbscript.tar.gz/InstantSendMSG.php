<?php
error_reporting(E_ALL);

class InstantSendMSG
{

    public static function sendsms($phones, $text, $multi_way = false)
    {
        InstantSendMSG::callMonWang($phones, $text);
        if($multi_way){
            InstantSendMSG::callCrbp($phones, $text);
        }
    }

    public static function sendsmsmultiphones($multi_phones, $text, $multi_way = false)
    {
        foreach($multi_phones as $phones){
            InstantSendMSG::callMonWang($phones, $text);
            if($multi_way){
                InstantSendMSG::callCrbp($phones, $text);
            }
        }
    }



    /**
     * 创蓝
     */
    public static function callCrbp($phones, $text)
    {
        $user = 'Yrxx888';
        $pass = 'Yinxiang7502';
        $host = 'http://222.73.117.156/msg';
        $product = '247626804';

        $start_time = microtime(true);
        $data = [
            'account' => $user,
            'pswd' => $pass,
            'mobile' => $phones,
            'msg' => $text,
            'needstatus' => false
        ];

        $ch = curl_init($host . '/HttpSendSM');
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_POST, true);
        $rs = curl_exec($ch);
        if(curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200) {
            $ok = true;
        }
        else {
            $ok = false;
        }
        curl_close($ch);
        echo $host.'/HttpSendSM'.'HTTP_REQUEST_CURL', json_encode($data, JSON_UNESCAPED_UNICODE).'|sms api: '.$rs.'MONITOR';
        echo "\n";
        //NewLogger::getInstance()->rpc($ok, $host.'/HttpSendSM', 'HTTP_REQUEST_CURL', json_encode($data, JSON_UNESCAPED_UNICODE).'|sms crbp api:'.$rs, 'MONITOR', microtime(true) - $start_time);
        return $ok;
    }

    // /**
    //  * 移通网络  ETONENET
    //  * @param string $phone
    //  * @param string $msg
    //  * @param int $dc
    //  * @return bool
    //  */
    // public static function callETone($phone, $msg, $dc = 8)
    // {
    //     $start_time = microtime(true);
    //     $data = [
    //         'spid' => self::$providers->etone->spid,
    //         'sppassword' => self::$providers->etone->pass,
    //         'command' => 'MT_REQUEST',
    //         'da' => $phone,
    //         'dc' => $dc,
    //         'sm' => self::eToneEncodeHexStr($msg, $dc),
    //     ];
    //     $ch = curl_init(self::$providers->etone->host);
    //     curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    //     curl_setopt($ch, CURLOPT_POST, true);

    //     $rs = curl_exec($ch);
    //     if(curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200) {
    //         $ok = true;
    //     }
    //     else {
    //         $ok = false;
    //     }
    //     curl_close($ch);
    //     NewLogger::getInstance()->rpc($ok, self::$providers->etone->host, 'HTTP_REQUEST_CURL', json_encode($data, JSON_UNESCAPED_UNICODE).'|sms crbp api:'.$rs, 'MONITOR', microtime(true) - $start_time);
    //     return $ok;
    // }

    /**
     * encode Hex String
     *
     * @param string $binStr
     * @param int $dataCoding
     * @param string $encode
     * @return string hex string
     */
    private static function eToneEncodeHexStr($binStr, $dataCoding = 8, $encode = "UTF-8")
    {
        if ($dataCoding == 15) { //GBK
            return bin2hex(mb_convert_encoding($binStr, "GBK", $encode));
        }
        elseif (($dataCoding & 0x0C) == 8) {   //UCS-2BE
            return bin2hex(mb_convert_encoding($binStr, "UCS-2BE", $encode));
        }
        else {    //ISO8859-1
            return bin2hex(mb_convert_encoding($binStr, "ASCII", $encode));
        }
    }

    /**
     * 梦网科技短信通道
     * @param string $phone 纯中国区号码，不必带86
     * @param string $msg
     * @return bool
     */
    public static function callMonWang($phone, $msg)
    {
        $user = 'J50153';
        $pass = '883192';
        $host = 'http://61.130.7.220:8023/MWGate/wmgw.asmx';
        $start_time = microtime(true);
        $data = [
            'userId' => $user,
            'password' => $pass,
            'pszMobis'=> $phone,
            'pszMsg' => $msg,
            'iMobiCount' => 1,
            'pszSubPort' => '*',
            'MsgId' => 1,
        ];
        $ch = curl_init($host . '/MongateSendSubmit');
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_POST, true);
        $rs = curl_exec($ch);
        if (curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200) {
            $ok = true;
        }
        else {
            $ok = false;
        }
        curl_close($ch);
        echo $host.'/MongateSendSubmit'.'HTTP_REQUEST_CURL', json_encode($data, JSON_UNESCAPED_UNICODE).'|sms mengwang api: '.$rs.'MONITOR';
        echo "\n";
        return $ok;
    }
}

//InstantSendMSG::sendsmsmultiphones(array('13524515129','13167002769'),'test for alarm 3',true);
