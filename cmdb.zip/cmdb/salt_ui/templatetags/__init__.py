# !/usr/bin/env python
#-*- coding: utf-8 -*-
#=============================================================================
#     FileName: __init__.py
#         Desc:
#       Author: 苦咖啡
#        Email: voilet@qq.com
#     HomePage: http://blog.kukafei520.net
#      Version: 0.0.1
#   LastChange: 2014-06-12
#      History: 
#=============================================================================
